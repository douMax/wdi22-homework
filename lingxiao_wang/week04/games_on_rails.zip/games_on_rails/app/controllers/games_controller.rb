class GamesController < ApplicationController

  def welcome
  end

end
